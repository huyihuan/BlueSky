﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebSystemBase.SystemClass;
using WebSystemBase.Utilities;

namespace WebWorld.SystemManage
{
    public partial class UserManage : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lbl_Message.InnerHtml = string.Format("当前系统用户数量 <b>{0}</b> 个。", DataBase.HEntityCommon.HEntity(new UserInformation()).EntityCount());
            }
        }

        protected void btn_Add_ServerClick(object sender, EventArgs e)
        {
            int nAdd = DataBase.Util.ParseInt(txt_AddNumber.Value, 0);
            if (nAdd <= 0)
            {
                PageUtil.PageAlert(this.Page, "请填写要新增的用户数量");
                return;
            }
            Server.ScriptTimeout = 10 * nAdd;
            int nId = DataBase.HEntityCommon.HEntity(new UserInformation()).EntityCount();
            nAdd += nId;
            DateTime dtBegin = DateTime.Now;
            for (int i = nId; i < nAdd; i++)
            {
                UserInformation oUser = new UserInformation();
                oUser.UserName = "huyihuan" + i;
                oUser.Password = "1";
                oUser.Age = 18;
                oUser.Gender = 1;
                oUser.NickName = "胡伊欢下属" + i;
                oUser.QQ = "814822671";
                oUser.PostCode = "471000";
                oUser.MSN = "5749230583";
                oUser.Email = "huyihuan@jzs.com.cn";
                oUser.CardID = "410489189508043674";
                UserInformation.Save(oUser);
            }
            lbl_Message.InnerHtml = string.Format("<br />新增完成，当前系统用户数量 <b>{0}</b> 个。", DataBase.HEntityCommon.HEntity(new UserInformation()).EntityCount());
            TimeSpan tsDuring = new TimeSpan(DateTime.Now.Ticks - dtBegin.Ticks);
            lbl_Message.InnerHtml += string.Format("<br />共用时 <b>{0}</b>s。", tsDuring.TotalSeconds);
        }

    }
}