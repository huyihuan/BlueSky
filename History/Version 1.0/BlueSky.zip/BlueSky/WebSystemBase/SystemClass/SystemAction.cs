﻿using System;
using System.Collections.Generic;
using System.Web;
using DataBase;

namespace WebSystemBase.SystemClass
{
    public class SystemAction : DataBase.Interface.IEntity
    {
	    public int Id;
	    public string Name;
	    public string Key;
        public int IsDefault; //功能默认Action, 1 代表默认
        public int FunctionId;
	    public string ActionType;
	    public string ActionValue;
	    public string Description;
	    public string ControlName;
	    public string Tip;
	    public string IconName;
	    public string Target;
	    public int IsPopup;
	    public int Width;
	    public int Height;
	    public int IsResize;
	    public int IsMove;
	    public int IsIncludeMinBox;
	    public int IsIncludeMaxBox;
	    public int IsShowInTaskBar;

        #region IEntity

        public string GetTableName() { return "SystemAction"; }
        public string GetKeyName() { return "Id"; }

        #endregion

        public static SystemAction Get(int _nId)
        {
            if (_nId <= 0)
                return null;
            SystemAction oGet = new SystemAction();
            SystemAction[] alist = (SystemAction[])HEntityCommon.HEntity(oGet).EntityList("Id=" + _nId);
            if (null == alist || alist.Length == 0)
                return null;
            if (alist.Length > 1)
                throw new Exception(string.Format("{0}-{1}:{2} exist mutil records", oGet.GetTableName(), oGet.GetKeyName(), _nId));
            return alist[0];
        }

        public static SystemAction[] GetFunctionAction(int _FunctionId)
        {
            if (_FunctionId <= 0)
                return null;
            SystemAction oGet = new SystemAction();
            SystemAction[] alist = (SystemAction[])HEntityCommon.HEntity(oGet).EntityList("FunctionId=" + _FunctionId);
            return alist;
        }

        public static void Delete(int _nId)
        {
            SystemAction oDel = Get(_nId);
            if (null == oDel)
                return;
            DataBase.HEntityCommon.HEntity(oDel).EntityDelete();
        }

        public static SystemAction[] List()
        {
            SystemAction[] alist = (SystemAction[])DataBase.HEntityCommon.HEntity(new SystemAction()).EntityList();
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }

        public static SystemAction[] List(string __strFilter, string __strSort, int __nPageIndex, int __nPageSize)
        {
            SystemAction oList = new SystemAction();
            SystemAction[] alist = (SystemAction[])DataBase.HEntityCommon.HEntity(oList).EntityList(__strFilter, "", __nPageIndex, __nPageSize);
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }
    }
}
