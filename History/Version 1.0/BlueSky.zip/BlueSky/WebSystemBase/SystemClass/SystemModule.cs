﻿using System;
using System.Collections.Generic;
using System.Text;
using DataBase;

namespace WebSystemBase.SystemClass
{
    public class SystemModule : DataBase.Interface.IEntity
    {
        public int Id;
        public string Name;
        public string Key;
        public string Controller;
        public string Description;

        #region IEntity

        public string GetTableName() { return "SystemModule"; }
        public string GetKeyName() { return "Id"; }

        #endregion

        public static SystemModule Get(int _nId)
        {
            if (_nId <= 0)
                return null;
            SystemModule oGet = new SystemModule();
            SystemModule[] alist = (SystemModule[])HEntityCommon.HEntity(oGet).EntityList("Id=" + _nId);
            if (null == alist || alist.Length == 0)
                return null;
            if (alist.Length > 1)
                throw new Exception(string.Format("{0}-{1}:{2} exist mutil records", oGet.GetTableName(), oGet.GetKeyName(), _nId));
            return alist[0];
        }

        public static void Delete(int _nId)
        {
            SystemModule oDel = Get(_nId);
            if (null == oDel)
                return;
            DataBase.HEntityCommon.HEntity(oDel).EntityDelete();
        }

        public static SystemModule[] List()
        {
            SystemModule[] alist = (SystemModule[])DataBase.HEntityCommon.HEntity(new SystemModule()).EntityList();
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }

        public static SystemModule[] List(string __strFilter, string __strSort, int __nPageIndex, int __nPageSize)
        {
            SystemModule oList = new SystemModule();
            SystemModule[] alist = (SystemModule[])DataBase.HEntityCommon.HEntity(oList).EntityList(__strFilter, "", __nPageIndex, __nPageSize);
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }
    }
}
