﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Collections;
using DataBase;
using System.Web.UI.WebControls;

namespace WebSystemBase.SystemClass
{
    public class SystemFunction : DataBase.Interface.IEntity
    {
        public int Id;
        public string Name;
        public string Key;
        public int ModuleId;
        public int ParentId;
        public string IconName;
        public string Description;
        
        public int Level; //功能的深度（默认值：1 即第一级，1,2,3....）

        #region IEntity

        public string GetTableName() { return "SystemFunction"; }
        public string GetKeyName() { return "Id"; }

        #endregion

        public static SystemFunction Get(int _nId)
        {
            if (_nId <= 0)
                return null;
            SystemFunction oGet = new SystemFunction();
            SystemFunction[] alist = (SystemFunction[])HEntityCommon.HEntity(oGet).EntityList("Id=" + _nId);
            if (null == alist || alist.Length == 0)
                return null;
            if (alist.Length > 1)
                throw new Exception(string.Format("{0}-{1}:{2} exist mutil records", oGet.GetTableName(), oGet.GetKeyName(), _nId));
            return alist[0];
        }

        public static void Delete(int _nId)
        {
            SystemFunction oDel = Get(_nId);
            if (null == oDel)
                return;
            SystemFunction[] alSons = GetFunctions(_nId, true);
            int nCount = alSons.Length;
            for (int i = 0; i < nCount; i++)
            {
                DataBase.HEntityCommon.HEntity(alSons[i]).EntityDelete();
            }
        }

        public static SystemFunction[] GetFunctions(int _nParentId, bool _bIncludeAllChildren)
        {
            string strFilter = "ParentId =" + _nParentId;
            if(_bIncludeAllChildren)
                strFilter = "ParentId >=" + _nParentId;
            SystemFunction[] alist = (SystemFunction[])DataBase.HEntityCommon.HEntity(new SystemFunction()).EntityList(strFilter);
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }

        public static SystemFunction[] GetFunctions(int _nParentId, string[] _alRoleItemIds, bool __bIncludeAllChildren)
        {
            string strFilter = "ParentId =" + _nParentId;
            if (__bIncludeAllChildren)
                strFilter = "ParentId >=" + _nParentId;
            strFilter += string.Format(" and Id in (select distinct FunctionId from {0} where RoleId in ({1}))",(new SystemRoleFunctionPermission()).GetTableName(), String.Join(",", _alRoleItemIds));
            SystemFunction[] alist = (SystemFunction[])DataBase.HEntityCommon.HEntity(new SystemFunction()).EntityList(strFilter);
            if (null == alist || alist.Length == 0)
                return null;
            return alist;
        }

        public static Hashtable GetParentIdToCount(SystemFunction[] __alFunctions)
        {
            Hashtable htParentIdToCount = new Hashtable();
            int nCount = __alFunctions.Length;
            for (int i = 0; i < nCount; i++)
            {
                int nParentId = __alFunctions[i].ParentId;
                int nChildrenCount = 0;
                for (int j = 0; j < nCount; j++)
                {
                    if (nParentId == __alFunctions[j].ParentId)
                        nChildrenCount++;
                }
                htParentIdToCount[nParentId] = nChildrenCount;
            }
            return htParentIdToCount;
        }
    }
}
