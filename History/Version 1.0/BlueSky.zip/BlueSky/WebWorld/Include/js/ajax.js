﻿function xmlHttpRequest() {
    if (XMLHttpRequest)
        return new XMLHttpRequest();
    var arrXHRS = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];
    var nXHRCount = arrXHRS.length;
    var xhrObject = new Object();
    for (var i = 0; i < nXHRCount; i++) {
        try {
            xhrObject = new ActiveXObject(arrXHRS[i]);
            break;
        }
        catch (e) { }
    }
    if (typeof xhrObject != undefined)
        return xhrObject;
    return null;
    alert("Ajax not supported!");
}