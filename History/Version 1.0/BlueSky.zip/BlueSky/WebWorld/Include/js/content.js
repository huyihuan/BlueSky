﻿window.onload = function() {
    setTimeout(function() { setFrameHeight(); }, 100);
    setTimeout(function() { bs_event_hideLoadingLayer(document); }, 200);
}
window.onresize = function() {
    setTimeout(function() { setFrameHeight(); }, 0);
}

function setFrameHeight() {
    if (document.addEventListener) {
        var divElements = document.getElementsByName("content");
        if (undefined != divElements && divElements.length != 0) {
            var docHeight = document.body.clientHeight;
            var docWidth = document.body.clientWidth;
            divElements[0].style.height = docHeight + "px";
            divElements[0].style.Width = docWidth + "px";
        } 
    }
}