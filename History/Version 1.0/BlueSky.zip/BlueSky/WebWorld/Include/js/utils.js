﻿var Utils = new Object();
function mousePosition(_targetWindow,e) {
    var xPos, yPos;
    e = e || _targetWindow.event;
    if (e.pageX) {
        xPos = e.pageX;
        yPos = e.pageY;
    } else {
        xPos = e.clientX + _targetWindow.document.body.scrollLeft - _targetWindow.document.body.clientLeft;
        yPos = e.clientY + _targetWindow.document.body.scrollTop - _targetWindow.document.body.clientTop;
    }
    return {X:xPos, Y:yPos};
}
Utils.documentSize = function(_documentRef) {
    var size = new Object;
    size.width = document.body.clientWidth;
    size.height = document.body.clientHeight;
    return size;
}
Utils.parseInt = function(_strValue, _defaultValue) {
    var parseValue = parseInt(_strValue);
    if (isNaN(parseValue) || parseValue == undefined || parseValue == null)
        return _defaultValue;
    return parseValue;
}
Utils.parseDouble = function(_strValue, _defaultValue) {
    var parseValue = parseFloat(_strValue);
    if (isNaN(parseValue) || parseValue == undefined || parseValue == null)
        return _defaultValue;
    return parseValue;
}

/*表单验证*/
Utils.vType = {
    Empty: "Empty",
    Email: "Email",
    Post: "Post",
    IDCard: "IDCard",
    Chinese: "Chinese",
    English: "English",
    Integer: "Integer"
}
Utils.vText = function(_vArguments) {
    if (!_vArguments.vtarget || _vArguments.vtarget == undefined || _vArguments.vtarget == null)
        _vArguments.vtarget = window;
    if (_vArguments.vtype == Utils.vType.Empty) {
        var inputRef = _vArguments.vtarget.document.getElementById(_vArguments.vid);
        var strValue = inputRef.value;
        if (strValue == "" || null == strValue || undefined == strValue) {
            inputRef.focus();
            if (_vArguments.ishint && null != _vArguments.ishint) {
                inputRef.className = inputRef.className + " txt-hint";
            }
            if (_vArguments.message && null != _vArguments.message && "" != _vArguments.message)
                alert(_vArguments.message);
            return false;
        }
        inputRef.className = inputRef.className.replace(" txt-hint", "");
        return true;
    }
    //如果未说明验证类型则返回false
    return false;
}