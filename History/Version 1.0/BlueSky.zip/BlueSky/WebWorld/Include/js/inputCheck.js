﻿function inputIsEmpty(_inputId, _alertMsg, _isHint) {
    var inputRef = document.getElementById(_inputId);
    if (!inputRef || null == inputRef || undefined == inputRef)
        return;
    var strValue = inputRef.value;
    if (strValue == "" || null == strValue || undefined == strValue) {
        inputRef.focus();
        if (_isHint && null != _isHint && true == _isHint) {
            inputRef.className = inputRef.className + " txt-hint";
        }
        if (_alertMsg && null != _alertMsg && "" != _alertMsg)
            alert(_alertMsg);
        return true;
    }
    inputRef.className = inputRef.className.replace(" txt-hint", "");
    return false;
}