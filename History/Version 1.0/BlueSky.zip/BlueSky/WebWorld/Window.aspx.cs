﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataBase;
using WebSystemBase.SystemClass;

namespace WebWorld
{
    public partial class Window : System.Web.UI.Page
    {
        public int nFunctionId = -1;
        protected void Page_Load(object sender, EventArgs e)
        {
            nFunctionId = PageUtil.GetQueryInt(this.Request, "functionid", -1);
            string strActionKey = PageUtil.GetQueryString(this.Request, "action");
            SystemFunction function = SystemFunction.Get(nFunctionId);
            if (null == function || nFunctionId <= 0)
                return;
            SystemModule module = SystemModule.Get(function.ModuleId);
            if (null == module)
                return;

            //int nCurrentUserId = SystemUtil.GetCurrentUserId();
            SystemAction[] alActions = SystemAction.GetFunctionAction(function.Id);
            if (null == alActions)
                return;
            string strControlKey = "";
            foreach (SystemAction action in alActions)
            {
                if (!string.IsNullOrEmpty(strActionKey) && action.Key.Equals(strActionKey))
                {
                    strControlKey = action.ControlName;
                    break;
                }
                else  if (string.IsNullOrEmpty(strActionKey) && action.IsDefault == 1)
                {
                    strControlKey = action.ControlName;
                    strActionKey = action.Key;
                    break;
                }
            }

            string strModule = module.Controller;
            string strOtherUrl = "";
            if (!string.IsNullOrEmpty(strOtherUrl) && strOtherUrl.Length > 4 && strOtherUrl.Substring(0, 4) == "http")
            {
                Response.Write(string.Format("<iframe frameborder=\"0\" src=\"{0}\" scrolling=\"auto\" height=\"100%\" width=\"100%\"></iframe>", strOtherUrl));
                return;
            }

            string strFunctionPath = string.IsNullOrEmpty(strOtherUrl) ? SystemUtil.ResovleFunctionUrl(strModule, strControlKey) : strOtherUrl;
            Control uc = LoadControl(strFunctionPath);
            ph.Controls.Add(uc);

            Control toolBar = uc.FindControl("toolBar");
            
            if (null != toolBar)
            {
                (toolBar as HtmlControl).Attributes["class"] = "toolBar";

                foreach (SystemAction action in alActions)
                {
                    HyperLink toolAction = new HyperLink();
                    toolAction.ID = "Action_" + action.Key;
                    toolAction.CssClass = action.Key == strActionKey ? "action-active" : "action-normal";
                    toolAction.ToolTip = action.Description;
                    toolAction.Attributes["onclick"] = action.Key == strActionKey ? "void(0);" : string.Format("window.location.href='Window.aspx?functionid={0}&action={1}'", nFunctionId, action.Key);
                    toolAction.NavigateUrl = "javascript:void(0);";

                    HtmlGenericControl spanText = new HtmlGenericControl("span");
                    spanText.InnerText = action.Name;

                    HtmlImage toolIcon = new HtmlImage();
                    toolIcon.Align = "absMiddle";
                    toolIcon.Attributes["hspace"] = "2";
                    toolIcon.Src = "~/Include/image/WindowImages/add.gif";

                    toolAction.Controls.Add(toolIcon);
                    toolAction.Controls.Add(spanText);
                    toolBar.Controls.Add(toolAction);
                }
            }
        }
    }
}
