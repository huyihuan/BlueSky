﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataBase
{
    public class Constants
    {
        public const int Yes = 1;
        public const int No = 0;
        public const string ItemSelect = "--请选择--";
        public const string ItemAll = "--全部--";
    }
}
