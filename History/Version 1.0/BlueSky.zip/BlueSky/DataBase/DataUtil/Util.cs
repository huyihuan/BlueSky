﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Reflection;
using System.Collections;

namespace DataBase
{
    public class Util
    {
        public static int ParseInt(string _strSource, int _iDefault)
        {
            int nReturnValue = 0;
            bool bParse = int.TryParse(_strSource, out nReturnValue);
            return bParse ? nReturnValue : _iDefault;
        }

        public static double ParseDoulbe(string _strSource, double _dDefault)
        {
            double dReturnValue = 0;
            bool bParse = double.TryParse(_strSource, out _dDefault);
            return bParse ? dReturnValue : _dDefault;
        }

        public static string MD5Encrypt(string _strSource)
        {
            if(string.IsNullOrEmpty(_strSource))
                return "";
            System.Security.Cryptography.MD5 md5Factory = System.Security.Cryptography.MD5.Create();
            byte[] byteSource = Encoding.Default.GetBytes(_strSource);
            byte[] byteMd5 = md5Factory.ComputeHash(byteSource);
            string strResult = BitConverter.ToString(byteMd5).Replace("-", "");
            return strResult;
        }

        public static string[] GetObjectFieldsList(object _oSource)
        {
            if (null == _oSource)
                return null;
            List<string> ltReturnList = new List<string>();
            Type oTp = _oSource.GetType();
            FieldInfo[] alFields = oTp.GetFields();
            foreach (FieldInfo item in alFields)
            {
                if (item.IsStatic)
                    continue;
                ltReturnList.Add(item.Name);
            }
            PropertyInfo[] alProperties = oTp.GetProperties();
            foreach (PropertyInfo item in alProperties)
                ltReturnList.Add(item.Name);
            return ltReturnList.ToArray();
        }

        public static object GetObjectFieldValue(object _oSource, string _strFieldName)
        {
            if (null == _oSource || string.IsNullOrEmpty(_strFieldName))
                return null;
            Type oTp = _oSource.GetType();
            FieldInfo field = oTp.GetField(_strFieldName);
            if (null == field)
                return null;
            return field.GetValue(_oSource);
        }

        public static Hashtable GetObjectFieldValueHash(object _oSource)
        {
            if (null == _oSource)
                return null;
            Hashtable htFieldValue = new Hashtable();
            Type oTp = _oSource.GetType();
            FieldInfo[] alFields = oTp.GetFields();
            foreach (FieldInfo item in alFields)
            {
                if (item.IsStatic)
                    continue;
                htFieldValue[item.Name] = item.GetValue(_oSource);
            }
            PropertyInfo[] alProperties = oTp.GetProperties();
            foreach (PropertyInfo item in alProperties)
                htFieldValue[item.Name] = item.GetValue(_oSource, null);
            return htFieldValue;
        }

        public static void VCodeSaveCurrent(string _strVCode)
        {
            HttpContext.Current.Session["bs_server_vcode"] = _strVCode;
        }

        public static string VCodeGetCurrent()
        {
            return HttpContext.Current.Session["bs_server_vcode"] + "";
        }

    }
}
